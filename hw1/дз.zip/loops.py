def loops():    
    a=int(input())
    if 1<=a<=20:
        for i in range (0,a):
            print(i**2)
    else:
        print('ERROR')
loops()