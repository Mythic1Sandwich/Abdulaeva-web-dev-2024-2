
def split_and_join():
    a=input()
    f=a.split()
    result = '-'.join(f)
    print(result)

split_and_join()