def division():
        
    a = int(input())
    b = int(input())
    if b==0:
        print(0)
    else:
        print(a//b)
        print(a/b)
division()